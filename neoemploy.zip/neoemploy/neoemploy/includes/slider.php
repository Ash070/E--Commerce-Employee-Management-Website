	<!-- Home -->

	<div class="home">
		
		<!-- Slider -->
		<div class="home_slider_container">
			<div class="owl-carousel owl-theme home_slider">
				
				<!-- Slide -->
				<div class="slide">
					<div class="background_image" style="background-image:url(images/economia-uber.jpg)"></div>
					<div class="home_slider_overlay"></div>
					<div class="slide_wrap d-flex flex-column align-items-start justify-content-center">
						<div class="home_container">
							<div class="container">
								<div class="row">
									<div class="col">
										<div class="home_content active">
											<div class="home_subtitle">Want Services!</div>
											<div class="home_title">
												<h1><span>Get</span> Your Service</h1>
												<h1>At your door step</h1>
											</div>
											<!--div class="button home_button"><a href="#">read more</a></div-->
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Slide -->
				<!--div class="slide">
					<div class="background_image" style="background-image:url(images/index.jpg)"></div>
					<div class="home_slider_overlay"></div>
					<div class="slide_wrap d-flex flex-column align-items-start justify-content-center">
						<div class="home_container">
							<div class="container">
								<div class="row">
									<div class="col">
										<div class="home_content">
											<div class="home_subtitle">go to the gym now!</div>
											<div class="home_title">
												<h1><span>never</span> limit</h1>
												<h1>yourself</h1>
											</div>
											<div class="button home_button"><a href="#">read more</a></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div-->

				<!-- Slide -->
				<!--div class="slide">
					<div class="background_image" style="background-image:url(images/index.jpg)"></div>
					<div class="home_slider_overlay"></div>
					<div class="slide_wrap d-flex flex-column align-items-start justify-content-center">
						<div class="home_container">
							<div class="container">
								<div class="row">
									<div class="col">
										<div class="home_content">
											<div class="home_subtitle">go to the gym now!</div>
											<div class="home_title">
												<h1><span>never</span> limit</h1>
												<h1>yourself</h1>
											</div>
											<div class="button home_button"><a href="#">read more</a></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div-->

			</div>
		</div>

	</div>