	<!-- Header -->

	<header class="header">
		<div class="header_wrap d-flex flex-row align-items-center justify-content-center">
			
			<!-- Logo -->
			<div class="logo"><a href="home"><img src="images/logo_1.png" alt=""></a></div>

			<!-- Main Nav -->
			<nav class="main_nav">
				<ul class="d-flex flex-row align-items-center justify-content-center">
					<li class="active"><a href="home">home</a></li>
					<li><a href="services">Services</a></li>
					<li><a href="aboutus">about us</a></li>
					<li><a href="join">Join Us</a></li>
					<li><a href="contactus">contact</a></li>
				</ul>
			</nav>

			<!-- Social -->
			<div class="social header_social">
				<form method="post" enctype="multipart/form-data" action="services">
					<ul class="d-flex flex-row align-items-center justify-content-start">
						<li><input class="form-control" type="text" name="location" placeholder="Enter city" style="background-color: #190A49; color: white" required></li>
						<li><button type="submit" name="search" class="btn" style="background-color: #190A49"><span class="fa fa-search" style="color: green;"></span></button></li>
						<?php
						if (isset($_SESSION['id']))
						{
						?>
						<li style="color: white"><a href="myorders" style="text-transform: none; font-weight: bold; color: white">Orders</a></li>
						<li style="color: white"><a href="logout.php" style="text-transform: none; font-weight: bold; color: white">Logout</a></li>
						<?php
						} else {
						?>
						<li style="color: white"><a href="userlogin" style="text-transform: none; font-weight: bold; color: white">Login</a></li>
					<?php } ?>
					</ul>
				</form>
			</div>

			<!-- Hamburger -->
			<div class="hamburger ml-auto"><i class="fa fa-bars" aria-hidden="true"></i></div>

		</div>
	</header>

	<!-- Fixed Header -->

	<header class="fixed_header">
		<div class="header_wrap d-flex flex-row align-items-center justify-content-center">
			
			<!-- Logo -->
			<div class="logo"><a href="home"><img src="images/logo_2.png" alt=""></a></div>

			<!-- Main Nav -->
			<nav class="main_nav">
				<ul class="d-flex flex-row align-items-center justify-content-center">
					<li class="active"><a href="home">home</a></li>
					<li><a href="services">Services</a></li>
					<li><a href="aboutus">about us</a></li>
					<li><a href="join">Join Us</a></li>
					<li><a href="contactus">contact</a></li>
				</ul>
			</nav>

			<!-- Social -->
			<div class="social header_social">
				<form method="post" enctype="multipart/form-data" action="services">
					<ul class="d-flex flex-row align-items-center justify-content-start">
						<li><input class="form-control" type="text" name="location" placeholder="Enter city" style="background-color: #190A49; color: white" required></li>
						<li><button type="submit" name="search" class="btn" style="background-color: #190A49"><span class="fa fa-search" style="color: green;"></span></button></li>
						<?php
						if (isset($_SESSION['id']))
						{
						?>
						<li style="color: white"><a href="myorders" style="text-transform: none; font-weight: bold; color: white">Orders</a></li>
						<li style="color: white"><a href="logout.php" style="text-transform: none; font-weight: bold; color: white">Logout</a></li>
						<?php
						} else {
						?>
						<li style="color: white"><a href="userlogin" style="text-transform: none; font-weight: bold; color: white">Login</a></li>
					<?php } ?>
					</ul>
				</form>
			</div>

			<!-- Hamburger -->
			<div class="hamburger ml-auto"><i class="fa fa-bars" aria-hidden="true"></i></div>

		</div>
	</header>

	<!-- Menu -->

	<div class="menu">
		<div class="menu_door door_left"></div>
		<div class="menu_door door_right"></div>
		<div class="menu_content d-flex flex-column align-items-center justify-content-center">
			<div class="menu_close">close</div>
			<div class="menu_nav_container">
				<nav class="menu_nav text-center">
					<ul>
						<li><a href="home">home</a></li>
						<li><a href="services">Services</a></li>
						<li><a href="aboutus">about us</a></li>
					<li><a href="join">Join Us</a></li>
						<li><a href="contactus">contact</a></li>
						<?php
						if (isset($_SESSION['id']))
						{
						?>
						<li style="color: white"><a href="myorders" style="text-transform: none; font-weight: bold; color: white">Orders</a></li>
						<li style="color: white"><a href="logout.php" style="text-transform: none; font-weight: bold; color: white">Logout</a></li>
						<?php
						} else {
						?>
						<li style="color: white"><a href="userlogin" style="text-transform: none; font-weight: bold; color: white">Login</a></li>
					<?php } ?>
					</ul>
				</nav>
			</div>
			<div class="social menu_social">
				<form method="post" enctype="multipart/form-data" action="services">
					<ul class="d-flex flex-row align-items-center justify-content-start">
						<li><input class="form-control" type="text" name="location" placeholder="Enter city" required style="background-color: #190A49; color: white"></li>
						<li><button type="submit" name="search" class="btn" style="background-color: #190A49"><span class="fa fa-search" style="color: green;"></span></button></li>

					</ul>
				</form>
			</div>
		</div>
	</div>