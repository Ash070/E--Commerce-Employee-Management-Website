-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 11, 2020 at 08:25 AM
-- Server version: 5.6.49-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `neoemploy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `aid` int(11) NOT NULL,
  `aname` varchar(250) NOT NULL,
  `aemail` varchar(250) NOT NULL,
  `apassword` varchar(250) NOT NULL,
  `aregdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`aid`, `aname`, `aemail`, `apassword`, `aregdate`) VALUES
(1, 'Admin Navjot Singh', 'enridise@gmail.com', 'a90b86d07e38c0fcd44fada077924f66', '2020-12-11 14:32:57'),
(2, 'Admin Raushan Kr. Jha', 'admin@gmail.com', '33ba24871ed154c5d12894eea9d6a9fa', '2020-12-11 14:56:54');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `cuid` int(11) NOT NULL,
  `cuname` varchar(250) NOT NULL,
  `cuemail` varchar(250) NOT NULL,
  `cusubject` varchar(250) NOT NULL,
  `cumessage` longtext NOT NULL,
  `cudate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`cuid`, `cuname`, `cuemail`, `cusubject`, `cumessage`, `cudate`) VALUES
(1, 'Navjot Singh', 'enridise@gmail.com', 'Test', 'This is a test mail for testing database connection\r\n', '2020-12-11 14:21:42');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `mobile` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `mobile`, `password`, `regdate`) VALUES
(1, 'Navjot Singh', 'enridise@gmail.com', '7033034637', 'a90b86d07e38c0fcd44fada077924f66', '2020-12-11 13:57:51'),
(2, 'New', 'rk@gmail.com', '9113764578', '33ba24871ed154c5d12894eea9d6a9fa', '2020-12-11 14:55:56');

-- --------------------------------------------------------

--
-- Table structure for table `employeregistration`
--

CREATE TABLE `employeregistration` (
  `eid` int(11) NOT NULL,
  `ename` varchar(250) NOT NULL,
  `emobile` varchar(250) NOT NULL,
  `eaddress` varchar(250) NOT NULL,
  `ecity` varchar(250) NOT NULL,
  `edistrict` varchar(250) NOT NULL,
  `estate` varchar(250) NOT NULL,
  `epincode` varchar(250) NOT NULL,
  `epost` varchar(250) NOT NULL,
  `eregdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeregistration`
--

INSERT INTO `employeregistration` (`eid`, `ename`, `emobile`, `eaddress`, `ecity`, `edistrict`, `estate`, `epincode`, `epost`, `eregdate`) VALUES
(1, 'Navjot Singh', '7033034637', 'Kachauri Gali Dira Paar', 'Patna City', 'Patna', 'Bihar', '800008', 'Car Driver', '2020-12-11 14:36:06'),
(2, 'Navjot Singh', '9113764578', 'Kachauri Gali', 'Patna', 'Patna', 'Bihar', '800008', 'Home Cleaner', '2020-12-11 14:40:13');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `oid` int(11) NOT NULL,
  `orderid` varchar(250) NOT NULL,
  `sid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `amount` varchar(250) NOT NULL,
  `splantype` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `mobile` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `state` varchar(250) NOT NULL,
  `zip` varchar(250) NOT NULL,
  `ddate` varchar(250) NOT NULL,
  `orderregdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`oid`, `orderid`, `sid`, `cid`, `amount`, `splantype`, `name`, `email`, `mobile`, `address`, `city`, `state`, `zip`, `ddate`, `orderregdate`) VALUES
(1, 'IMPS42294918989966', 3, 1, '34999', 'Yearly', 'Navjot Singh', 'enridise@gmail.com', '7033034637', 'Harimandir Gali', 'Patna', 'Bihar', '800008', '2020-12-12', '2020-12-11 14:52:50');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `pid` int(11) NOT NULL,
  `orderid` varchar(250) NOT NULL,
  `transactionid` varchar(250) NOT NULL,
  `transactionamount` varchar(250) NOT NULL,
  `transactionstatus` varchar(250) NOT NULL,
  `transactionmode` varchar(250) NOT NULL,
  `pregdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`pid`, `orderid`, `transactionid`, `transactionamount`, `transactionstatus`, `transactionmode`, `pregdate`) VALUES
(1, 'IMPS42294918989966', 'COD', '34999', 'DUE', 'cod', '2020-12-11 14:52:50');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `sid` int(11) NOT NULL,
  `sname` varchar(250) NOT NULL,
  `sprice1` varchar(250) NOT NULL,
  `sprice2` varchar(250) NOT NULL,
  `sprice3` varchar(250) NOT NULL,
  `sdetails` varchar(250) NOT NULL,
  `sdescription` varchar(250) NOT NULL,
  `slocation` varchar(250) NOT NULL,
  `simage` varchar(250) NOT NULL,
  `sregdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`sid`, `sname`, `sprice1`, `sprice2`, `sprice3`, `sdetails`, `sdescription`, `slocation`, `simage`, `sregdate`) VALUES
(1, 'Service 1', '199', '1499', '14999', 'Service 1', 'This is the best service you have ever get in your life. This is the best service you have ever get in your life. This is the best service you have ever get in your life. This is the best service you have ever get in your life. This is the best servi', 'Patna', '5fd38543881ec8.11189534.jpg', '2020-12-11 14:42:11'),
(2, 'Service 2', '299', '2499', '24999', 'Service 2', 'This is the best service you have ever get in your life. This is the best service you have ever get in your life. This is the best service you have ever get in your life. This is the best service you have ever get in your life. This is the best servi', 'Samastipur', '5fd38543881ec8.11189534.jpg', '2020-12-11 14:42:11'),
(3, 'Service 3', '399', '3499', '34999', 'Service 3', 'This is the best service you have ever get in your life. This is the best service you have ever get in your life. This is the best service you have ever get in your life. This is the best service you have ever get in your life. This is the best servi', 'Patna', '5fd38543881ec8.11189534.jpg', '2020-12-11 14:42:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`cuid`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employeregistration`
--
ALTER TABLE `employeregistration`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `cuid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employeregistration`
--
ALTER TABLE `employeregistration`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
