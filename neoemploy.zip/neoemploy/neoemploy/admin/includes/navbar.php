	<!-- Header -->

	<header class="header">
		<div class="header_wrap d-flex flex-row align-items-center justify-content-center">
			
			<!-- Logo -->
			<div class="logo"><a href="#"><img src="../images/logo_1.png" alt=""></a></div>

			<!-- Main Nav -->
			<nav class="main_nav">
				<ul class="d-flex flex-row align-items-center justify-content-center">
					<li class="active"><a href="index.php">home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="join.php">Joins</a></li>
					<li><a href="contact.php">contact</a></li>
				</ul>
			</nav>

			<!-- Social -->
			<div class="social header_social">
					<ul class="d-flex flex-row align-items-center justify-content-start">
						<li style="color: white"><a href="myorders.php" style="text-transform: none; font-weight: bold; color: white">Orders</a></li>
						<li style="color: white"><a href="logout.php" style="text-transform: none; font-weight: bold; color: white">Logout</a></li>
					</ul>
			</div>

			<!-- Hamburger -->
			<div class="hamburger ml-auto"><i class="fa fa-bars" aria-hidden="true"></i></div>

		</div>
	</header>

	<!-- Fixed Header -->

	<header class="fixed_header">
		<div class="header_wrap d-flex flex-row align-items-center justify-content-center">
			
			<!-- Logo -->
			<div class="logo"><a href="#"><img src="images/logo_2.png" alt=""></a></div>

			<!-- Main Nav -->
			<nav class="main_nav">
				<ul class="d-flex flex-row align-items-center justify-content-center">
					<li class="active"><a href="index.php">home</a></li>
					<li><a href="services.php">Services</a></li>
					<li><a href="join.php">Joins</a></li>
					<li><a href="contact.php">contact</a></li>
				</ul>
			</nav>

			<!-- Social -->
			<div class="social header_social">
					<ul class="d-flex flex-row align-items-center justify-content-start">
						<li style="color: white"><a href="myorders.php" style="text-transform: none; font-weight: bold; color: white">Orders</a></li>
						<li style="color: white"><a href="logout.php" style="text-transform: none; font-weight: bold; color: white">Logout</a></li>
					</ul>
			</div>

			<!-- Hamburger -->
			<div class="hamburger ml-auto"><i class="fa fa-bars" aria-hidden="true"></i></div>

		</div>
	</header>

	<!-- Menu -->

	<div class="menu">
		<div class="menu_door door_left"></div>
		<div class="menu_door door_right"></div>
		<div class="menu_content d-flex flex-column align-items-center justify-content-center">
			<div class="menu_close">close</div>
			<div class="menu_nav_container">
				<nav class="menu_nav text-center">
					<ul>
						<li><a href="index.php">home</a></li>
						<li><a href="services.php">Services</a></li>
					<li><a href="join.php">Joins</a></li>
						<li><a href="contact.php">contact</a></li>
						<li style="color: white"><a href="myorders.php" style="text-transform: none; font-weight: bold; color: white">Orders</a></li>
						<li style="color: white"><a href="logout.php" style="text-transform: none; font-weight: bold; color: white">Logout</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</div>