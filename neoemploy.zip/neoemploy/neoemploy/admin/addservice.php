<?php 
	
	include('includes/database.php');
	session_start();
	if (!isset($_SESSION['aid'])) {
		echo "<script>window.location.href='index.php';</script>";
	}
?>

<?php

if (isset($_POST['apply'])) {

	$sname = $_POST['sname'];
	$sprice1 = $_POST['sprice1'];
	$sprice2 = $_POST['sprice2'];
	$sprice3 = $_POST['sprice3'];
	$sdetails = $_POST['sdetails'];
	$sdescription = $_POST['sdescription'];
	$slocation = $_POST['slocation'];
	$simage = $_FILES['simage']['name'];

	$fileName = $_FILES['simage']['name'];
	$fileTmpName = $_FILES['simage']['tmp_name'];

	$fileSize = $_FILES['simage']['size'];

	$fileError = $_FILES['simage']['error'];
	$fileType = $_FILES['simage']['type'];

	$fileExt = explode('.', $fileName);
	$fileActualExt = strtolower(end($fileExt));

	$allowed = array('png', 'jpg', 'jpeg');

	if (in_array($fileActualExt, $allowed)) {
		if ($fileError === 0) {
			if ($fileSize < 5242880) {
				$fileNameNew = uniqid('', true).".".$fileActualExt;
				$fileDestination = '../images/services/'.$fileNameNew;
				move_uploaded_file($fileTmpName, $fileDestination);
				$sqll = "INSERT INTO services (sname, sprice1, sprice2, sprice3, sdetails, sdescription, slocation, simage) values ('$sname', '$sprice1', '$sprice2', '$sprice3', '$sdetails', '$sdescription', '$slocation', '$fileNameNew')";
				$reslt = mysqli_query($con,$sqll);
				if ($reslt) {
					echo "<script> alert('Service Added Successfully!');window.location.href='services.php';</script>";
				}else {
					echo "<script> alert('Error. Something went wrong!')</script>";
				}
				
			} else {
				echo "<script> alert('Error. File size is too high. File size must be less then 5 MB!');</script>";
			}
		} else {
			echo "<script> alert('Error Occured!');</script>";
		}
	} else {
		echo "<script> alert('Error. You can only upload png, jpg, jpeg!');</script>";
	}
	
} 

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Imploy Services | Add Services</title>
<link rel="icon" type="icon" href="../images/3.png">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sportify template project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap-4.1.2/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.3.4/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.3.4/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.3.4/animate.css">
<link rel="stylesheet" type="text/css" href="styles/classes.css">
<link rel="stylesheet" type="text/css" href="styles/classes_responsive.css">
</head>
<body>

<div class="super_container">
	
	<?php include('includes/navbar.php'); ?>

	<!-- Home -->

	<div class="home">
		<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/classes.jpg" data-speed="0.8"></div>
		<div class="home_overlay"></div>
		<div class="home_container d-flex flex-column align-items-center justify-content-center">
			<div class="home_title"><h1>Add Services</h1></div>
		</div>
	</div>


	<!-- CTA -->

	<div class="cta">
		<div class="container">
			<div class="row">
				<div class="col-xl-10 offset-xl-1">
					<div class="cta_content">
						<h3 class="text-center">Add Services</h3>
						<div class="cta_text text-center">
							<form method="post" enctype="multipart/form-data">
								<div class="form-group">
									<input class="form-control" type="text" name="sname" placeholder="Enter service name" required>
								</div>
								<div class="form-group">
									<input class="form-control" maxlength="10" type="text" name="sprice1" placeholder="Enter service price for Daily Basis" required>
								</div>
								<div class="form-group">
									<input class="form-control" maxlength="10" type="text" name="sprice2" placeholder="Enter service price for Monthly Basis" required>
								</div>
								<div class="form-group">
									<input class="form-control" maxlength="10" type="text" name="sprice3" placeholder="Enter service price for Yearly Basis" required>
								</div>
								<div class="form-group">
									<input class="form-control" type="text" name="sdetails" placeholder="Enter service short details" required>
								</div>
								<div class="form-group">
									<textarea class="form-control" type="text" name="sdescription" placeholder="Enter service description" required></textarea>
								</div>
								<div class="form-group">
									<input class="form-control" type="text" name="slocation" placeholder="Enter service city" required>
								</div>
								<div class="form-group">
									<input class="form-control" type="file" name="simage" placeholder="Enter service image" required>
								</div>

								<div class="form-group">
									<input type="submit" class="btn button home_button" name="apply" value="Add services">
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


<?php include('includes/footer.php'); ?>