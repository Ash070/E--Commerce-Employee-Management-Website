<?php

	session_start();
	unset($_SESSION['aid']);
	unset($_SESSION['aname']);
	unset($_SESSION['aemail']);
  	header("Location: index.php");

?>