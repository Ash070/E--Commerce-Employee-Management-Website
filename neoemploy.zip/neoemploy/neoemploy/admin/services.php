<?php 
	
	include('includes/database.php');
	session_start();
	if (!isset($_SESSION['aid'])) {
		echo "<script>window.location.href='index.php';</script>";
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Imploy Services | My Services</title>
<link rel="icon" type="icon" href="../images/3.png">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sportify template project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap-4.1.2/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.3.4/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.3.4/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.3.4/animate.css">
<link rel="stylesheet" type="text/css" href="styles/classes.css">
<link rel="stylesheet" type="text/css" href="styles/classes_responsive.css">
</head>
<body>

<div class="super_container">
	
	<?php include('includes/navbar.php'); ?>

	<!-- Home -->

	<div class="home">
		<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="../images/blog.jpg" data-speed="0.8"></div>
		<div class="home_overlay"></div>
		<div class="home_container d-flex flex-column align-items-center justify-content-center">
			<div class="home_title"><h1>My Services</h1></div>
		</div>
	</div>


	<!-- CTA -->

	<div class="cta">
		<div class="container">
			<div class="row">
				<div class="col-xl-10 offset-xl-1">
					<div class="cta_content">
						<div class="cta_text text-center">
							<table class="table table-responsive" style="border: 1px solid">
								<tr>
									<td>
										<a href="addservice.php"><input type="submit" value="Add Services" class="btn btn-primary" style="float: right;"></a>
									</td>
								</tr>
								<?php
								$sql = "SELECT * FROM services ORDER BY sid DESC";
								$result = mysqli_query($con,$sql);
								if (mysqli_num_rows($result) > 0) {
								?>
								<tr>
									<th>#</th>
									<th>Service Image</th>
									<th>Service Name</th>
									<th>Service Price</th>
									<th>Service Details</th>
									<th>Service Description</th>
									<th>Service Location</th>
									<th>Action</th>
								</tr>
								<?php
				                    while ($rows=mysqli_fetch_array($result))
				                    {
				                    	$sid = $rows['sid'];
				                    	$sprice1 = $rows['sprice1'];
				                    	$sprice2 = $rows['sprice2'];
				                    	$sprice3 = $rows['sprice3'];
				                    	$simage = $rows['simage'];
				                    	$sdetails = $rows['sdetails'];
				                    	$sdescription = $rows['sdescription'];
				                    	$slocation = $rows['slocation'];
				                    	$sname = $rows['sname'];

			                    ?>
								<tr>
									<td>#</td>
									<td><img src="../images/services/<?= $simage ?>" width="500px" height="100px"></td>
									<td><a href="http://localhost/neoemploy/service-details.php?id=<?= $sid ?>" target="_blank"><?= $sname ?></a></td>
									<td>
										Daily: &#8377;<?= $sprice1 ?>
										Monthly: &#8377;<?= $sprice2 ?>
										Yearly: &#8377;<?= $sprice3 ?>
									</td>
									<td><?= $sdetails ?></td>
									<td><?= substr($sdescription, 0,50) ?>...</td>
									<td><?= $slocation ?></td>
									<td>
										<form method="post" enctype="multipart/form-data">
											<input type="hidden" name="sid" value="<?= $sid ?>">
											<input type="submit" class="btn btn-danger" name="delete" value="Delete">
										</form>
									</td>
								</tr>
							<?php
									}
								} else {
									echo "<h2 style='color: ; text-align: center'>You haven't added service yet.<br>Please add something first!</h2>"; 
								}
							?>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


<?php include('includes/footer.php'); ?>

<?php

if (isset($_POST['delete'])) {
	$sid = $_POST['sid'];

	$delete = "DELETE from services where sid = '$sid'";
	$res = mysqli_query($con,$delete);
	if ($res) {
		echo "<script> alert('Service Deleted Successfully!');window.location.href='services.php';</script>";
	} else {
		echo "<script> alert('Error. Something went wrong!');window.location.href='services.php';</script>";
	}
}

?>